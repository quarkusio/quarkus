INSERT INTO MyEntity(id, name) VALUES(3, 'other-load-script sql load script entity');
